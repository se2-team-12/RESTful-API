var express = require('express');
var router = express.Router({});
var mongoose = require('mongoose');
mongoose.connect('localhost/swe2');
var Schema = mongoose.Schema;

var AssetManager = require('../models/hearbeatModel');


/* GET gateway listing. */
router.get('/', function (req, res) {

    AssetManager.find()
        .exec()
        .then(docs =>{
            console.log(docs);
            res.status(200).json(docs);
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({
                error: err
            });
        });

});

router.put('/', function (req, res) {
    res.status(202).json({
        "Status": "put ok"
    });
    //res.status(202).send();
});

router.delete('/', function (req, res) {
    res.status(202).json({
        "Status": "delete ok"
    })
    //res.status(202).send();
    process.exit();
});

router.patch('/', function (req, res) {
    res.status(202).json({
        "Status": "patch ok"
    })
    //res.status(202).json(req.body);
});

router.options('/', function (req, res) {
    res.header('Allow', 'GET, POST, PUT, PATCH, DELETE, OPTIONS, HEAD').status(204).send();
});

module.exports = router;
