var express = require('express');
var router = express.Router({});


/* GET home page. */
router.get('/', function (req, res) {
    res.render('index');
});


router.get('/get-data', function(req,res, next){

});

router.post('/insert', function(req, res, next) {

});

router.post('/insert', function(req, res, next) {

});

router.post('/insert', function(req, res, next) {

});


router.options('/', function (req, res) {
    res.header('Allow', 'GET').status(204).send();
});

module.exports = router;