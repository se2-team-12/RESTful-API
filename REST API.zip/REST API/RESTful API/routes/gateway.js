var express = require('express');
var router = express.Router({});
var mongoose = require('mongoose');
mongoose.connect('localhost/swe2');
var Schema = mongoose.Schema;

var Gateway = require('../models/hearbeatModel');


/* GET gateway listing. */
router.get('/', function (req, res) {

    Gateway.find()
        .exec()
        .then(docs =>{
            console.log(docs);
            res.status(200).json(docs);
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({
                error: err
            });
        });

});

router.post('/', function (req, res) {

    var gateway = new Gateway({
        GatewayId: req.body.GatewayId,
        TimeStamp: req.body.TimeStamp,
        status: req.body.status
    });

    gateway
        .save()
        .then(result => {
            console.log(result);
            res.status(201).json({
                postedGateway: result
            });
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({
                error: err
            });
        });
});

router.put('/', function (req, res) {
        var gateway = new Gateway({
        GatewayId: req.body.GatewayId,
        TimeStamp: req.body.TimeStamp,
        status: req.body.status
    });
  gateway
  .findOneAndUpdate({_id: req.params.GatewayId}, req.body, {new: true}, function(err, heartbeat) {
    if (err)
      res.send(err);
    res.json(heartbeat);
  });

});

router.delete('/', function (req, res) {
        var gateway = new Gateway({
        GatewayId: req.body.GatewayId,
        TimeStamp: req.body.TimeStamp,
        status: req.body.status
    });
  gateway.remove({
    _id: req.params.GatewayId
  }, function(err, heartbeat) {
    if (err)
      res.send(err);
    res.json({ message: 'Heartbeat successfully deleted' });
  });
    //res.status(202).send();
    process.exit();
});

router.patch('/', function (req, res) {
    res.status(202).json({
        "Status": "patch ok"
    })
    //res.status(202).json(req.body);
});

router.options('/', function (req, res) {
    res.header('Allow', 'GET, POST, PUT, PATCH, DELETE, OPTIONS, HEAD').status(204).send();
});

module.exports = router;
