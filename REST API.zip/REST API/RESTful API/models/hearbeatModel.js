'use strict';
var mongoose = require('mongoose');
var Schema = mongoose.Schema;


var HeartbeatSchema = new Schema({
    GatewayId : String,
    TimeStamp: String,
    status: {
    type: [{
      type: String,
      enum: ['pending', 'Alive', 'Dead']
    }],
    default: ['pending']
  }
});

module.exports = mongoose.model('Heartbeat', HeartbeatSchema);