const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const logger = require('morgan');
const mongoose = require('mongoose');

mongoose.Promise = global.Promise;
mongoose.connect("mongodb://localhost/swe2");

const indexRouter = require('./routes/index');
const gatewayRouter = require('./routes/gateway');
const clientSideRouter = require('./routes/clientSide');

const app = express();

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({extended: false}));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/api/', indexRouter);
app.use('/api/gateway', gatewayRouter);
app.use('/api/clientSide', clientSideRouter);

module.exports = app;
